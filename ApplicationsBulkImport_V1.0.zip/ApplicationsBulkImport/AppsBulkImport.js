const csv = require('csv-parser');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;
const stripBom = require('strip-bom-stream');
const fs = require('fs');
const nodemon = require('./nodemon.json');
const https = require('https');
const FormData = require("form-data");
const axios = require("axios");

var myArgs = process.argv.slice(2);

var outFile = 'out_'+Date.now()+'.csv';

const csvWriter = createCsvWriter({
  path: outFile,
  header: [
    {id: 'CI ID', title: 'CI ID'},
    {id: 'Name', title: 'Name'},
    {id: 'Status', title: 'Status'},
    {id: 'Description', title: 'Description'},
    {id: 'Environment', title: 'Environment'},
    {id: 'Security Business Impact Analysis', title: 'Security Business Impact Analysis'},
    {id: 'Type', title: 'Type'},
    {id: 'Development Contact', title: 'Development Contact'},
    {id: 'Business Unit', title: 'Business Unit'},
    {id: 'Internet Facing', title: 'Internet Facing'},
    {id: 'Vendor Hosted', title: 'Vendor Hosted'},
    {id: 'Hosts', title: 'Hosts'},
    {id: 'URL', title: 'URL'},
    {id: 'Tags', title: 'Tags'}
  ]   
});

createApplicatonsCSVFile();
createApplicationsInASE();
 
function createApplicatonsCSVFile()
{
  var apps = [];
  fs.createReadStream(myArgs[0])
  .pipe(stripBom())
  .pipe(csv())
  .on('data', (row) => {
    var data = {};
    data["CI ID"] = row["CI ID"];
    
    var name = row["CI ID"] + '_' + row["CI Name"] + '_' + row["URL"];
    data["Name"] = name;
    
    data["Status"] = (typeof row["Status"] != 'undefined') ? row["Status"] : "Inactive"; //New
    data["Description"] = row["Description"];
    data["Environment"] = (typeof row["Environment"] != 'undefined') ? row["Environment"] : "NonProd"; //New
    data["Security Business Impact Analysis"] = row["Security Business Impact Analysis"];    //New
    data["Type"] = row["Type"];
    data["Development Contact"] = row["PSSTECH Support"];
    data["Business Unit"] = row["Business Unit"];
    data["Internet Facing"] = row["Internet Facing"]; //New
    data["Vendor Hosted"] = row["Vendor Hosted"]; //New
    data["Hosts"] = row["Hosts"]; 
    data["URL"] = row["URL"];
    data["Tags"] = row["Tags"];

    apps.push(data);
  })
  .on('end', () => {
    csvWriter.writeRecords(apps)
      .then(() => {
        console.log('CSV file successfully processed');
      });
  });
}

async function  createApplicationsInASE()
{
  var token = await login();
  const form = new FormData();
  const stream = fs.createReadStream(outFile);
  form.append('uploadedfile', stream);

  const formHeaders = form.getHeaders();

  const instance = axios.create({
    httpsAgent: new https.Agent({  
      rejectUnauthorized: false
    })
  });

  const restURL = 'https://'+nodemon.env.ASEHostname+':'+nodemon.env.ASEPort+'/'+nodemon.env.ASEContext+'/api/appimport';

  instance.post(restURL,form, {
    headers: {
      'Content-Type': 'multipart/form-data',
      'Cookie': 'asc_session_id='+token,
      ...formHeaders,
    },
  })
  .then(response => 
    {
      console.log("data = "+ response.data);
    })
  .catch(error => 
    {
      console.log("error = "+ error);
    })
}


function login()
{
  return new Promise(resolve => {
    try
    {
        const data = JSON.stringify({
            "userId": nodemon.env.userId,
            "password": nodemon.env.password,
            "featureKey": "AppScanEnterpriseUser"
          });
    
        const options = {
            hostname: nodemon.env.ASEHostname,
            port: nodemon.env.ASEPort,
            path: '/ase/api/login',
            rejectUnauthorized: false,
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Content-Length': data.length
            }
        };
    
        const req1 = https.request(options, (res1) => {
            res1.on('data', (d) => {
                var respObj = JSON.parse(d);
  
                if (typeof respObj.sessionId != 'undefined')
                {
                    console.log('token = '+respObj.sessionId);
                    resolve(respObj.sessionId);
                }
                else
                {
                    console.log("ASE has not returned the token. Must be wrong credentials.");
                }
  
                return;
            });
        });          
        req1.on('error', (error) => {
            console.log("error = "+error);
        });        
  
        req1.write(data);
        req1.end();
    }    
    catch (e)
    {
        console.log("e = "+e);
    }    
  });
}



