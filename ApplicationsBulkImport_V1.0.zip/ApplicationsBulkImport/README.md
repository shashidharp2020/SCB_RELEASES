# ApplicationsBulkImport

It is a JS script to import applications from CSV file to the ASE system.
---------------------------
Installation Steps:
---------------------------
- Create an application specific attributes in the ASE following the snapshots added to the document "ASE_Changes.docx".

- Edit the file "./ApplicationsBulkImport/nodemon.json" to update below properties

	a) ASEHostname		=> Hostname of the box where ASE server is installed.
	b) ASEPort		=> Modify only if the port is different from 9443.
	c) ASEContext		=> Modify only if the context used in the ASE url is other than 'ase'.
	d) userId		=> AppScan Enterprise username having Administrator privileges
	e) password		=> Password of the user
 
- From command prompt run the command "node .\AppsBulkImport.js <path to the csv file>" from the directory "./ApplicationsBulkImport"

Ex:
node .\AppsBulkImport.js D:\Downloads\logs\Bulk-Apps-Import\SCB_sampledata.csv
----------------------------
